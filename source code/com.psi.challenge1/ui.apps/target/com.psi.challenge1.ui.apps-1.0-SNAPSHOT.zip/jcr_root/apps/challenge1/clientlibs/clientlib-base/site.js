// Homepage specific
function openPage(go_to_url){
	 document.location.href =  "/content/challenge1/en/testcurrency_page" +"/"+ go_to_url;
 }

// For table pages

